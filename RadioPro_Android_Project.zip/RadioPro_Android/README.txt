RADIOPRO ANDROID PROJECT

This is an Android Studio project containing the RadioPro offline radiography study app.

BUILD THE APK
1. Install Android Studio on a computer.
2. Open Android Studio and choose Open.
3. Select the RadioPro_Android folder (the folder containing settings.gradle).
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be at:
   app/build/outputs/apk/debug/app-debug.apk

INSTALL ON YOUR ANDROID PHONE
Transfer app-debug.apk to your phone, open it, and allow installation from that source if Android asks.

FEATURES
- 10 radiography subject areas and topic lists
- Multiple-choice exam practice with explanations
- Revision notes and search
- Quiz statistics and subject performance
- Offline operation; study progress is stored locally on the device

NOTES
- The question bank and notes are starter material, not a complete curriculum.
- The app does not connect to patient records or provide clinical decision support.
- This source project has not been compiled or tested on a physical Android device.
